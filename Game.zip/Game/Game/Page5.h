#pragma once
#include<iostream>
#include "Troops.h"
#include "Headquarter.h"
#include "Technology.h"
#include "Resources.h"
#include "Page1.h"
#include "Page2.h"
#include "Page3.h"
#include "Page4.h"
#include "IPage.h"
#include"Landship.h"
using namespace std;

void PrintPage5()
{
	cout << "                                Attack in Progress                              " << endl;
	cout << "________________________________________________________________________________" << endl;
	cout << "\n";



}

