#pragma once

#include<iostream>
#include "Defensive.h"
using namespace std;

struct Resources {
	int GoldCoins;
	int Steel;
};

Resources R1 = { 2000,0 }; //The initial goldcoin = 1000 and initial steel = 0

